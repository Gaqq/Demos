package part2;
//
//Assignment 3 
//Question: 1 
//Written by: Jack Fraser 40266009 
//

public interface TariffPolicy {

	String evaluateTrade(double proposedTariff, double minimumTariff);
	
	
}
